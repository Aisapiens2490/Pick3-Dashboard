export interface State {
  id: string;
  name: string;
  active: boolean;
}

export interface DrawResult {
  id: string;
  date: string;
  state: string;
  numbers: string;
  drawTime: 'day' | 'evening';
}

export interface NumberAnalysis {
  sum: number;
  rootSum: number;
  oddEvenPattern: 'allOdd' | 'allEven' | 'twoOddOneEven' | 'twoEvenOneOdd';
  highLowPattern: 'allLow' | 'allHigh' | 'twoLowOneHigh' | 'twoHighOneLow';
}