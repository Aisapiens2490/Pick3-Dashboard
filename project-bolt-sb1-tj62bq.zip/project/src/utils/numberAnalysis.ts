export const calculateSum = (numbers: string): number => {
  return numbers.split('').reduce((acc, digit) => acc + parseInt(digit), 0);
};

export const calculateRootSum = (numbers: string): number => {
  let sum = calculateSum(numbers);
  
  while (sum > 9) {
    sum = sum.toString().split('').reduce((acc, digit) => acc + parseInt(digit), 0);
  }
  
  return sum;
};

export const isOdd = (num: number): boolean => num % 2 !== 0;
export const isLow = (num: number): boolean => num >= 0 && num <= 5;

export const getOddEvenPattern = (numbers: string): string => {
  const digits = numbers.split('').map(Number);
  const oddCount = digits.filter(d => isOdd(d)).length;
  
  if (oddCount === 3) return 'allOdd';
  if (oddCount === 0) return 'allEven';
  if (oddCount === 2) return 'twoOddOneEven';
  return 'twoEvenOneOdd';
};

export const getHighLowPattern = (numbers: string): string => {
  const digits = numbers.split('').map(Number);
  const lowCount = digits.filter(d => isLow(d)).length;
  
  if (lowCount === 3) return 'allLow';
  if (lowCount === 0) return 'allHigh';
  if (lowCount === 2) return 'twoLowOneHigh';
  return 'twoHighOneLow';
};