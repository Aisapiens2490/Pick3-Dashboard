import { DrawResult } from '../types/lottery';
import { isOdd, isLow } from './numberAnalysis';

interface ChartData {
  oddOnlyLow: number;
  oddOnlyHigh: number;
  evenOnlyLow: number;
  evenOnlyHigh: number;
  twoOddOneEvenLow: number;
  twoOddOneEvenHigh: number;
  twoEvenOneOddLow: number;
  twoEvenOneOddHigh: number;
  winningCombinations: Array<{
    type: 'oddOnly' | 'evenOnly' | 'twoOddOneEven' | 'twoEvenOneOdd';
    isHigh: boolean;
    value: number;
    state: string;
  }>;
}

export const calculateChartData = (results: DrawResult[]): ChartData => {
  const initialData: ChartData = {
    oddOnlyLow: 0,
    oddOnlyHigh: 0,
    evenOnlyLow: 0,
    evenOnlyHigh: 0,
    twoOddOneEvenLow: 0,
    twoOddOneEvenHigh: 0,
    twoEvenOneOddLow: 0,
    twoEvenOneOddHigh: 0,
    winningCombinations: [],
  };

  return results.reduce((acc, result) => {
    const digits = result.numbers.split('').map(Number);
    const oddCount = digits.filter(d => isOdd(d)).length;
    const lowCount = digits.filter(d => isLow(d)).length;
    const highCount = 3 - lowCount;
    const value = parseInt(result.numbers);
    const isHighNumber = !isLow(Math.floor(value / 100));

    let type: 'oddOnly' | 'evenOnly' | 'twoOddOneEven' | 'twoEvenOneOdd';
    if (oddCount === 3) {
      type = 'oddOnly';
      acc.oddOnlyLow += lowCount;
      acc.oddOnlyHigh += highCount;
    } else if (oddCount === 0) {
      type = 'evenOnly';
      acc.evenOnlyLow += lowCount;
      acc.evenOnlyHigh += highCount;
    } else if (oddCount === 2) {
      type = 'twoOddOneEven';
      acc.twoOddOneEvenLow += lowCount;
      acc.twoOddOneEvenHigh += highCount;
    } else {
      type = 'twoEvenOneOdd';
      acc.twoEvenOneOddLow += lowCount;
      acc.twoEvenOneOddHigh += highCount;
    }

    acc.winningCombinations.push({
      type,
      isHigh: isHighNumber,
      value,
      state: result.state
    });

    return acc;
  }, initialData);
};