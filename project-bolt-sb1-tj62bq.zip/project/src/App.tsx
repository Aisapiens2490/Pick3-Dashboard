import React, { useState } from 'react';
import { ChakraProvider, Box, VStack, Heading } from '@chakra-ui/react';
import { DrawInput } from './components/DrawInput';
import { ResultsTable } from './components/ResultsTable';
import { AnalysisChart } from './components/AnalysisChart';
import { DrawResult } from './types/lottery';
import { calculateChartData } from './utils/chartDataCalculator';

function App() {
  const [results, setResults] = useState<DrawResult[]>([]);

  const handleDrawSubmit = (data: {
    state: string;
    numbers: string;
    drawTime: 'day' | 'evening';
    date: string;
  }) => {
    const newResult: DrawResult = {
      id: Date.now().toString(),
      ...data
    };

    // Keep only the last 10 results per state and draw time
    const filteredResults = results.filter(
      r => !(r.state === data.state && r.drawTime === data.drawTime)
    ).slice(-9);

    setResults([...filteredResults, newResult]);
  };

  const chartData = calculateChartData(results);

  return (
    <ChakraProvider>
      <Box p={4}>
        <VStack spacing={8}>
          <Heading>Pick 3 Lottery Dashboard</Heading>
          <DrawInput onSubmit={handleDrawSubmit} />
          <ResultsTable results={results} />
          <Box w="full" h="500px">
            <AnalysisChart data={chartData} />
          </Box>
        </VStack>
      </Box>
    </ChakraProvider>
  );
}

export default App;