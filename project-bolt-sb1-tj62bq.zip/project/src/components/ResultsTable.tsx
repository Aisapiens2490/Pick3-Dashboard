import React from 'react';
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Box,
} from '@chakra-ui/react';
import { DrawResult } from '../types/lottery';
import { calculateSum, calculateRootSum, getOddEvenPattern, getHighLowPattern } from '../utils/numberAnalysis';

interface ResultsTableProps {
  results: DrawResult[];
}

export const ResultsTable: React.FC<ResultsTableProps> = ({ results }) => {
  return (
    <Box overflowX="auto">
      <Table variant="simple">
        <Thead>
          <Tr>
            <Th>Date</Th>
            <Th>State</Th>
            <Th>Time</Th>
            <Th>Numbers</Th>
            <Th>Sum</Th>
            <Th>Root Sum</Th>
            <Th>Odd/Even</Th>
            <Th>High/Low</Th>
          </Tr>
        </Thead>
        <Tbody>
          {results.map((result) => (
            <Tr key={result.id}>
              <Td>{result.date}</Td>
              <Td>{result.state}</Td>
              <Td>{result.drawTime}</Td>
              <Td>{result.numbers}</Td>
              <Td>{calculateSum(result.numbers)}</Td>
              <Td>{calculateRootSum(result.numbers)}</Td>
              <Td>{getOddEvenPattern(result.numbers)}</Td>
              <Td>{getHighLowPattern(result.numbers)}</Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </Box>
  );
};