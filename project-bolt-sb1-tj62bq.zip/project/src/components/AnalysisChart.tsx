import React from 'react';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend,
  ScatterController,
  PointElement
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { chartOptions } from './chart/ChartConfig';
import { transformToChartData } from './chart/ChartDataTransformer';
import { DrawResult } from '../types/lottery';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ScatterController,
  PointElement
);

interface AnalysisChartProps {
  data: {
    oddOnlyLow: number;
    oddOnlyHigh: number;
    evenOnlyLow: number;
    evenOnlyHigh: number;
    twoOddOneEvenLow: number;
    twoOddOneEvenHigh: number;
    twoEvenOneOddLow: number;
    twoEvenOneOddHigh: number;
    winningCombinations: DrawResult[];
  };
}

export const AnalysisChart: React.FC<AnalysisChartProps> = ({ data }) => {
  const scatterData = transformToChartData(data.winningCombinations);

  const chartData = {
    labels: ['Odd Only', 'Even Only', '2 Odd + 1 Even', '2 Even + 1 Odd'],
    datasets: [
      {
        label: 'Low (0-5)',
        data: [80, 80, 160, 160],
        backgroundColor: '#FFD700',
        stack: 'stack0',
        type: 'bar' as const,
      },
      {
        label: 'High (6-9)',
        data: [50, 50, 100, 100],
        backgroundColor: '#FFA07A',
        stack: 'stack0',
        type: 'bar' as const,
      },
      {
        label: 'Winning Combinations',
        data: scatterData,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        pointStyle: 'circle',
        radius: 5,
        type: 'scatter' as const,
      }
    ]
  };

  return (
    <div style={{ width: '100%', height: '500px' }}>
      <Bar data={chartData} options={chartOptions} />
    </div>
  );
};