import { ChartOptions } from 'chart.js';

export const chartOptions: ChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: {
    intersect: false,
  },
  scales: {
    x: {
      stacked: true,
      grid: {
        display: true,
        color: '#E5E5E5',
        drawBorder: false,
      },
    },
    y: {
      stacked: true,
      grid: {
        display: true,
        color: '#E5E5E5',
        drawBorder: false,
      },
      min: 0,
      max: 300,
      ticks: {
        stepSize: 50,
      },
      title: {
        display: true,
        text: 'Total Numbers',
      }
    }
  },
  plugins: {
    title: {
      display: true,
      text: 'Low and High Distribution by Combination Type',
      font: {
        size: 16,
        weight: 'bold'
      },
      padding: 20
    },
    legend: {
      position: 'top',
      labels: {
        usePointStyle: true,
        padding: 20,
      }
    }
  }
};