import { DrawResult } from '../../types/lottery';

export interface ChartDataPoint {
  x: number;
  y: number;
  state: string;
  value: number;
}

export const getXPosition = (type: string): number => {
  switch (type) {
    case 'oddOnly': return 0;
    case 'evenOnly': return 1;
    case 'twoOddOneEven': return 2;
    case 'twoEvenOneOdd': return 3;
    default: return 0;
  }
};

export const getYPosition = (isHigh: boolean, type: string): number => {
  const baseHeight = {
    oddOnly: 80,
    evenOnly: 80,
    twoOddOneEven: 160,
    twoEvenOneOdd: 160
  }[type] || 80;
  
  return isHigh ? baseHeight * 1.5 : baseHeight * 0.5;
};

export const transformToChartData = (results: DrawResult[]): ChartDataPoint[] => {
  return results.map(result => {
    const value = parseInt(result.numbers);
    const firstDigit = Math.floor(value / 100);
    const isHigh = firstDigit >= 6;
    const type = result.type;

    return {
      x: getXPosition(type),
      y: getYPosition(isHigh, type),
      state: result.state,
      value: value
    };
  });
};