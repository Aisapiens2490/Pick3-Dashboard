import React, { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  Select,
  VStack,
  useToast
} from '@chakra-ui/react';

interface DrawInputProps {
  onSubmit: (data: {
    state: string;
    numbers: string;
    drawTime: 'day' | 'evening';
    date: string;
  }) => void;
}

export const DrawInput: React.FC<DrawInputProps> = ({ onSubmit }) => {
  const [state, setState] = useState('');
  const [numbers, setNumbers] = useState('');
  const [drawTime, setDrawTime] = useState<'day' | 'evening'>('day');
  const [date, setDate] = useState('');
  const toast = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (numbers.length !== 3 || !/^\d{3}$/.test(numbers)) {
      toast({
        title: 'Invalid input',
        description: 'Please enter exactly 3 digits',
        status: 'error',
        duration: 3000,
      });
      return;
    }

    onSubmit({ state, numbers, drawTime, date });
    setNumbers('');
  };

  return (
    <Box as="form" onSubmit={handleSubmit} p={4}>
      <VStack spacing={4}>
        <FormControl isRequired>
          <FormLabel>State</FormLabel>
          <Select
            value={state}
            onChange={(e) => setState(e.target.value)}
          >
            <option value="">Select State</option>
            <option value="NC">North Carolina</option>
            <option value="IN">Indiana</option>
            <option value="PA">Pennsylvania</option>
            <option value="TN">Tennessee</option>
          </Select>
        </FormControl>

        <FormControl isRequired>
          <FormLabel>Numbers</FormLabel>
          <Input
            value={numbers}
            onChange={(e) => setNumbers(e.target.value)}
            placeholder="Enter 3 digits"
            maxLength={3}
          />
        </FormControl>

        <FormControl isRequired>
          <FormLabel>Draw Time</FormLabel>
          <Select
            value={drawTime}
            onChange={(e) => setDrawTime(e.target.value as 'day' | 'evening')}
          >
            <option value="day">Day</option>
            <option value="evening">Evening</option>
          </Select>
        </FormControl>

        <FormControl isRequired>
          <FormLabel>Date</FormLabel>
          <Input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </FormControl>

        <Button type="submit" colorScheme="blue">
          Add Draw Result
        </Button>
      </VStack>
    </Box>
  );
};